#!/bin/bash

rm -rf ./tmp